# أبو علي - Telegram Bot for Cloudflare Workers

Add these Cloudflare Worker secrets:
- BOT_TOKEN = your BotFather token
- WEBHOOK_SECRET = a random secret such as AbuAliWebhook2026

The admin ID is already set to 8423554712.

After deployment, open:
https://YOUR-WORKER.workers.dev/set-webhook?key=abu-ali-setup-8423554712

Then the Telegram bot will use the Worker webhook.
